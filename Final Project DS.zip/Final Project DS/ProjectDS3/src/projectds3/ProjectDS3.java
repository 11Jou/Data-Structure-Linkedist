
package projectds3;
import java.util.Scanner;
public class ProjectDS3 {
    public static void main(String[] args) {
      Scanner sc = new Scanner(System.in);
        System.out.println("Enter the number of nodes: ");
          int n = sc.nextInt();
        System.out.println("Enter the number of edges: ");
          int m = sc.nextInt();
          Graph graph= new Graph(n);
        System.out.println("Enter the edges: (to) (from)");
         int array[]=new int [m];        
         int i =0;
        while (i <m){
          int to = sc.nextInt();
          int from = sc.nextInt();
        graph.ArrayCost(to, from, Math.abs(to-from));
         i++;
        }
        graph.FullArray();
        graph.FindMinimumCost(graph.Cost); }}
 class Graph {
   int nodes;
    int [][] Cost;
    int Parent[];
  public Graph(int n){
         nodes = n; 
         Cost = new int [nodes+1][nodes+1];
         Parent=new int[nodes+1];
}
  public void ArrayCost(int to, int from, int cost){
       Cost[to][from] = cost;
}
  public void FullArray(){
      for(int i=0;i<nodes+1;i++){
          for(int j=0;j<nodes+1;j++)
              if(Cost[i][j]==0)
                  Cost[i][j]=Integer.MAX_VALUE;
      }
  }
  void FindMinimumCost(int X[][]){
      int MinCost=0;
      for(int i=0;i<nodes+1;i++)
         Parent[i]=i;
int Edge=0;
while(Edge<nodes-1){
    int Min=Integer.MAX_VALUE;
    int b=-1;
    int a=-1;
    for(int i=0;i<nodes+1;i++){
        for(int j=0;j<nodes+1;j++){
            if(find(i)!=find(j)&&X[i][j]<Min){
                Min=X[i][j];
                a=i;
                b=j; } }  }
    union1(a,b);
    Edge++;
    MinCost=+Min;}
    System.out.println("The Cost = " + MinCost);
  }
  int find(int i){
      while(Parent[i]!=i)
          i=Parent[i];
      return i;
  }
  void union1(int i , int j){
      int a=find(i);
      int b=find(j);
      Parent[a]=b;
  }
}